# Credits

This resource pack uses the **NegativeSpaceFont** by [AmberWat](https://github.com/AmberWat/NegativeSpaceFont).

Repository: https://github.com/AmberWat/NegativeSpaceFont

The font has been integrated into this resource pack for convenience.  
No external dependencies are required to use this resource pack.

All rights to **NegativeSpaceFont** belong to its respective creator.